module ipn.ejercicio3_2 {
    requires javafx.controls;
    requires javafx.fxml;

    opens ipn.ejercicio3_2 to javafx.fxml;
    exports ipn.ejercicio3_2;
}
