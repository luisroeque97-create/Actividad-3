package ipn.ejercicio3_2;

import java.io.IOException;
import javafx.scene.control.Label;
import java.util.Random;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.ProgressBar;

public class PrimaryController {
    @FXML private Label liebreTxt;
    @FXML private Label tortugaTxt;
    @FXML private ProgressBar liebreBar;
    @FXML private ProgressBar tortugaBar;

    @FXML
    private void switchToSecondary() throws IOException {
        liebreBar.setProgress(0.0);
        tortugaBar.setProgress(0.0);
        liebreTxt.setText("Liebre !Esta corriendo¡");
        tortugaTxt.setText("Tortuga !Esta corriendo¡");

        // --- HILO DE LA TORTUjA ---
        Thread hiloTortuga = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 1; i <= 100; i++) {
                    try {
                        // Velocidad constante de la tortuga
                        Thread.sleep(80);
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();
                    }
                    
                    final double avance = i / 100.0;
                    
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            tortugaBar.setProgress(avance);
                            if (avance >= 1.0) {
                                tortugaTxt.setText("¡La Tortuga ganó! 🐢🏆");
                            }
                        }
                    });
                }
            }
        });
        Thread hiloLiebre = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 1; i <= 100; i++) {
                    try {
                        if (i == 50) {
                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
                                    liebreTxt.setText("La Liebre !Se durmio¡");
                                }
                            });
                            Thread.sleep(3500);
                            Platform.runLater(new Runnable() {
                                @Override
                                public void run() {
                                    liebreTxt.setText("Liebre: ¡A correr de nuevo!");
                                }
                            });
                        } else {
                            Thread.sleep(50);
                        }
                    } catch (InterruptedException ex) {
                        Thread.currentThread().interrupt();
                    }
                    
                    final double avance = i / 100.0;
                    
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            liebreBar.setProgress(avance);
                            if (avance >= 1.0 && !tortugaTxt.getText().contains("ganó")) {
                                liebreTxt.setText("¡La Liebre ganó! 🐇🏆");
                            }else{ 
                                if(avance >= 1.0){
                                    liebreTxt.setText("¡La Liebre perdio! 🐇");
                                }
                            }
                        }
                    });
                }
            }
        });

        // Lanzamos ambos hilos
        hiloTortuga.start();
        hiloLiebre.start();
    }
}
