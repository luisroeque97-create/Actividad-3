module ipn.ejercicio3_1 {
    requires javafx.controls;
    requires javafx.fxml;

    opens ipn.ejercicio3_1 to javafx.fxml;
    exports ipn.ejercicio3_1;
}
