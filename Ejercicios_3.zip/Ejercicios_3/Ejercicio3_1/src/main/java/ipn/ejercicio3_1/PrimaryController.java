package ipn.ejercicio3_1;

import java.io.IOException;
import javafx.application.Platform;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ProgressBar;
import javafx.scene.control.TextField;

public class PrimaryController implements Initializable{
    
    @FXML private TextField click;
    @FXML private Button primaryButton;
    @FXML private Button esperar;
    @FXML private ProgressBar prg;
    
    int clicks = 0;

    @FXML
    private void switchToSecondary(){
        clicks += 1;
        click.setText("" + clicks);
    }
    
    @FXML
    private void btnEsperar(){
        // clicks += 1; click.setText("" + clicks);
        Thread h = new Thread(new Runnable() {
            @Override
            public void run() {
                for (int i = 1; i <= 100; i++) {
                    try {
                        Thread.sleep(50);
                    } catch(InterruptedException ex) {
                        Thread.currentThread().interrupt();
                    }
                    
                    final double avance = i / 100.0;
                    
                    Platform.runLater(new Runnable() {
                        @Override
                        public void run() {
                            prg.setProgress(avance);
                        }
                    });
                }
            }
        });
        
        h.start();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        click.setText("" + clicks);
        prg.setProgress(0);
    }
}

